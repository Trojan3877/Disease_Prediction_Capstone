# Disease Prediction Capstone

## Project Overview
The **Disease Prediction Capstone** project aims to build a robust machine learning pipeline to predict the onset of diabetes using the PIMA Indian Diabetes Dataset. The focus is on creating modular, well-commented code that follows best practices in machine learning engineering and ensuring comprehensive evaluation with quantifiable metrics and visualizations. 

## Repository Structure
```
Disease_Prediction_Capstone/
│
├── data/
│   ├── raw/            # Raw dataset files (e.g., CSV)
│   └── processed/      # Preprocessed data ready for modeling
│
├── notebooks/
│   ├── 01_EDA.ipynb    # Exploratory Data Analysis
│   └── 02_Model_Training.ipynb  # Model training and evaluation
│
├── src/
│   ├── data_loader.py
│   ├── preprocessing.py
│   ├── model.py
│   ├── train.py
│   ├── evaluate.py
│   └── utils.py
│
├── models/
│   ├── trained_model.pkl  # Serialized trained model
│
├── results/
│   ├── roc_curve.png
│   ├── confusion_matrix.png
│   └── feature_importance.png
│
├── requirements.txt
├── README.md
└── LICENSE
```

## Setup Instructions
1. **Clone the repository:**
   ```bash
   git clone <repository_url>
   cd Disease_Prediction_Capstone
   ```

2. **Create and activate a virtual environment:**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

3. **Install required packages:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Download the dataset:**
   - The PIMA Indian Diabetes dataset can be downloaded from:
     - Kaggle: https://www.kaggle.com/uciml/pima-indians-diabetes-database
     - UCI Machine Learning Repository: https://archive.ics.uci.edu/ml/datasets/Pima+Indians+Diabetes

   Place the downloaded CSV file in `data/raw/` folder.

## How to Use
1. **Exploratory Data Analysis:**
   - Open `notebooks/01_EDA.ipynb` and run cells to explore the dataset and generate visualizations.

2. **Model Training:**
   - Open `notebooks/02_Model_Training.ipynb` or run the training script:
     ```bash
     python src/train.py --data_path data/raw/diabetes.csv --output_model models/trained_model.pkl
     ```

3. **Model Evaluation:**
   - Run the evaluation script:
     ```bash
     python src/evaluate.py --model_path models/trained_model.pkl --data_path data/raw/diabetes.csv
     ```

4. **Results:**
   - Visualizations (ROC curve, confusion matrix, feature importance) will be saved in the `results/` folder.

## Code Overview
- **`data_loader.py`:** Functions to load raw data into pandas DataFrame.
- **`preprocessing.py`:** Data cleaning, feature engineering, and scaling functions.
- **`model.py`:** Defines model architectures (Logistic Regression and XGBoost).
- **`train.py`:** Training pipeline with cross-validation and model serialization.
- **`evaluate.py`:** Evaluation pipeline to generate metrics and save visualizations.
- **`utils.py`:** Utility functions for plotting and common tasks.

## Requirements
See `requirements.txt` for the full list of required Python packages.

## License
This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## Future Work
- Extend to other disease datasets (e.g., cardiovascular, cancer).
- Deploy the model as an API using Flask or FastAPI.
- Integrate with a web dashboard for real-time predictions.